import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';

function TopicDetails() {
  const { id } = useParams(); // Extract topic ID from the URL
  const [topic, setTopic] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    axios
      .get(`http://127.0.0.1:5000/api/topics/${id}`)
      .then((response) => {
        setTopic(response.data);
        setLoading(false);
      })
      .catch((error) => {
        console.error(error);
        setError('Failed to load topic details.');
        setLoading(false);
      });
  }, [id]);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>{error}</div>;
  }

  return (
    <div>
      <h1>{topic.name}</h1>
      <p>{topic.description}</p>
      <div dangerouslySetInnerHTML={{ __html: topic.summary }} />
    </div>
  );
}

export default TopicDetails;
