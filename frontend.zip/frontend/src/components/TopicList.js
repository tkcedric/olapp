import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './TopicList.css'; // Create a CSS file for styling
import { Link } from 'react-router-dom';

function TopicList() {
  const [topics, setTopics] = useState([]);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    axios
      .get('http://127.0.0.1:5000/api/topics')
      .then((response) => {
        setTopics(response.data);
        setError(null);
      })
      .catch((error) => {
        console.error('Error fetching topics:', error);
        setError('Failed to load topics. Please try again later.');
      });
  }, []);

  return (
    <div className="topics-container">
      <h1>Topics</h1>
      {error && <div className="error-message">{error}</div>}
      <div className="topics-grid">
        {topics.map((topic) => (
          <div
            key={topic.id}
            className="topic-card"
            onClick={() => navigate(`/topics/${topic.id}`)}
          >
            <h2>{topic.name}</h2>
            <p>{topic.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default TopicList;
