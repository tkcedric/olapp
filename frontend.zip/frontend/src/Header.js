import React from 'react';
import logo from './assets/ic_launcher.png';
import './App.css';

function Header() {
  return (
    <header>
      <img src={logo} alt="App Logo" className="app-logo" />
    </header>
  );
}

export default Header;
