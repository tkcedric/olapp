import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './styles.css';
import logo from './assets/ic_launcher.png';
import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import TopicList from './TopicList';
import TopicDetails from './TopicDetails'; // Placeholder for now

function App() {
  const [topics, setTopics] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    axios
      .get('http://127.0.0.1:5000/api/topics') // Flask API endpoint
      .then((response) => {
        setTopics(response.data);
        setLoading(false);
      })
      .catch((error) => {
        console.error('Error fetching topics:', error);
        setError(true);
        setLoading(false);
      });
  }, []);

  return (
    <div className="app-container">
      <header className="app-header">
      <img src={logo} alt="App Logo" className="app-logo" />
        <h1>GCE O/L Computer Science</h1>
      </header>
      <main className="topics-container">
        {loading && <p className="loading">Loading topics...</p>}
        {error && <p className="error">Failed to load topics. Please try again later.</p>}
        <ul className="topics-list">
          {topics.map((topic) => (
            <li key={topic.id} className="topic-item">
              <h2 className="topic-title">{topic.name}</h2>
              <p className="topic-description">{topic.description}</p>
            </li>
          ))}
        </ul>
        <Router>
      <Routes>
        <Route path="/" element={<TopicList />} />
        <Route path="/topics/:id" element={<TopicDetails />} />
      </Routes>
    </Router>
      </main>
    </div>
  );
  
}

export default App;
